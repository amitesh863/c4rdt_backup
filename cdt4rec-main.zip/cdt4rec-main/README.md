
# CDT4Rec Submitted to SIGIR23 for review

For running the code, just simply type the following in the running path:

``
python3 experiment.py
``

# Required Packages
VirtualTB (https://github.com/eyounx/VirtualTaobao)

gyms

PyTorch

# Environments

The provided code can be run on the online simulator - VirtualTB.

If you are interested in how to run the code on the offline dataset, please refers to this link(https://github.com/luozachary/drl-rec)



